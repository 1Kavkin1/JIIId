﻿using System.Drawing;
using System.Windows.Forms;

namespace UserApp
{
    partial class MainForm
    {
        private Button btnAuth;
        private Button btnTheme;

        private void InitializeComponent()
        {
            this.btnAuth = new Button();
            this.btnTheme = new Button();

            this.SuspendLayout();

            // btnAuth
            this.btnAuth.Location = new Point(60, 40);
            this.btnAuth.Size = new Size(180, 40);
            this.btnAuth.Text = "Login / Register";
            this.btnAuth.Click += new System.EventHandler(this.btnAuth_Click);

            // btnTheme
            this.btnTheme.Location = new Point(60, 100);
            this.btnTheme.Size = new Size(180, 40);
            this.btnTheme.Text = "Toggle Theme";
            this.btnTheme.Click += new System.EventHandler(this.btnTheme_Click);

            // MainForm
            this.ClientSize = new Size(320, 220);
            this.Controls.Add(this.btnAuth);
            this.Controls.Add(this.btnTheme);
            this.Text = "Main Menu";

            this.ResumeLayout(false);
        }
    }
}