using System.Windows.Forms;

namespace UserApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnAuth_Click(object sender, EventArgs e)
        {
            new AuthForm().ShowDialog();
        }

        private void btnTheme_Click(object sender, EventArgs e)
        {
            ThemeManager.DarkMode = !ThemeManager.DarkMode;
            ThemeManager.Apply(this);
        }
    }
}