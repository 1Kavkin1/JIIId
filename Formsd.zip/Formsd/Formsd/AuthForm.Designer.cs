﻿using System.Drawing;
using System.Windows.Forms;

namespace UserApp
{
    partial class AuthForm
    {
        private Label lblUser;
        private Label lblPass;
        private TextBox txtUser;
        private TextBox txtPass;
        private Button btnLogin;
        private Button btnRegister;
        private CheckBox chkShow;

        private void InitializeComponent()
        {
            this.lblUser = new Label();
            this.lblPass = new Label();
            this.txtUser = new TextBox();
            this.txtPass = new TextBox();
            this.btnLogin = new Button();
            this.btnRegister = new Button();
            this.chkShow = new CheckBox();

            this.SuspendLayout();

            // lblUser
            this.lblUser.Location = new Point(30, 20);
            this.lblUser.Text = "Username";

            // txtUser
            this.txtUser.Location = new Point(30, 45);
            this.txtUser.Size = new Size(220, 23);

            // lblPass
            this.lblPass.Location = new Point(30, 80);
            this.lblPass.Text = "Password";

            // txtPass
            this.txtPass.Location = new Point(30, 105);
            this.txtPass.Size = new Size(220, 23);
            this.txtPass.UseSystemPasswordChar = true;

            // chkShow
            this.chkShow.Location = new Point(30, 135);
            this.chkShow.Text = "Show password";
            this.chkShow.CheckedChanged += new System.EventHandler(this.chkShow_CheckedChanged);

            // btnLogin
            this.btnLogin.Location = new Point(30, 170);
            this.btnLogin.Size = new Size(100, 35);
            this.btnLogin.Text = "Login";
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);

            // btnRegister
            this.btnRegister.Location = new Point(150, 170);
            this.btnRegister.Size = new Size(100, 35);
            this.btnRegister.Text = "Register";
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);

            // AuthForm
            this.ClientSize = new Size(320, 260);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.txtUser);
            this.Controls.Add(this.lblPass);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.chkShow);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.btnRegister);
            this.Text = "Auth";

            this.ResumeLayout(false);
        }
    }
}