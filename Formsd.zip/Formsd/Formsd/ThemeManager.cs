﻿using System.Drawing;
using System.Windows.Forms;

namespace UserApp
{
    public static class ThemeManager
    {
        public static bool DarkMode = false;

        public static void Apply(Form form)
        {
            var back = DarkMode ? Color.FromArgb(30, 30, 30) : Color.White;
            var fore = DarkMode ? Color.White : Color.Black;

            form.BackColor = back;

            foreach (Control c in form.Controls)
            {
                c.BackColor = back;
                c.ForeColor = fore;
            }
        }
    }
}