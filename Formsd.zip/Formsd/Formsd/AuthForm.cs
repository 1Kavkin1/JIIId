﻿using System.Windows.Forms;

namespace UserApp
{
    public partial class AuthForm : Form
    {
        public AuthForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, System.EventArgs e)
        {
            if (UserManager.Login(txtUser.Text, txtPass.Text))
                MessageBox.Show("Login success");
            else
                MessageBox.Show("Wrong credentials");
        }

        private void btnRegister_Click(object sender, System.EventArgs e)
        {
            if (UserManager.Register(txtUser.Text, txtPass.Text))
                MessageBox.Show("User created");
            else
                MessageBox.Show("User already exists");
        }

        private void chkShow_CheckedChanged(object sender, System.EventArgs e)
        {
            txtPass.UseSystemPasswordChar = !chkShow.Checked;
        }
    }
}