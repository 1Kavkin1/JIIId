﻿using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace UserApp
{
    public static class UserManager
    {
        private static Dictionary<string, string> users = new();

        public static bool Register(string user, string pass)
        {
            if (users.ContainsKey(user))
                return false;

            users[user] = Hash(pass);
            return true;
        }

        public static bool Login(string user, string pass)
        {
            return users.ContainsKey(user) && users[user] == Hash(pass);
        }

        private static string Hash(string input)
        {
            using var md5 = MD5.Create();
            var bytes = md5.ComputeHash(Encoding.UTF8.GetBytes(input));

            StringBuilder sb = new();
            foreach (var b in bytes)
                sb.Append(b.ToString("x2"));

            return sb.ToString();
        }
    }
}